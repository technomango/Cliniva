import { Component, OnInit } from "@angular/core";
@Component({
  selector: "app-staff-profile",
  templateUrl: "./staff-profile.component.html",
  styleUrls: ["./staff-profile.component.sass"],
})
export class StaffProfileComponent implements OnInit {
  constructor() {}
  ngOnInit(): void {}
}
