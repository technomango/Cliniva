import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-form-dialog",
  templateUrl: "./form-dialog.component.html",
  styleUrls: ["./form-dialog.component.sass"],
})
export class FormDialogComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
