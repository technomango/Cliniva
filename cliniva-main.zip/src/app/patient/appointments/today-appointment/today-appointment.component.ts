import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-today-appointment",
  templateUrl: "./today-appointment.component.html",
  styleUrls: ["./today-appointment.component.sass"],
})
export class TodayAppointmentComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
