import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-billing",
  templateUrl: "./billing.component.html",
  styleUrls: ["./billing.component.sass"],
})
export class BillingComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
