import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-medical-records",
  templateUrl: "./medical-records.component.html",
  styleUrls: ["./medical-records.component.sass"],
})
export class MedicalRecordsComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
