import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-prescriptions",
  templateUrl: "./prescriptions.component.html",
  styleUrls: ["./prescriptions.component.sass"],
})
export class PrescriptionsComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
