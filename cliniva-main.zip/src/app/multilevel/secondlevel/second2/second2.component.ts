import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-second2",
  templateUrl: "./second2.component.html",
  styleUrls: ["./second2.component.sass"],
})
export class Second2Component implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
