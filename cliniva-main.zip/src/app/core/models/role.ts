export enum Role {
  All = "All",
  Admin = "Admin",
  Doctor = "Doctor",
  Patient = "Patient",
}
